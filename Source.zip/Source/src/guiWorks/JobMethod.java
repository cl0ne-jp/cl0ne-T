package guiWorks;

public class JobMethod {

	public static void getValues(String userName, char[] pwd) {
		if(userName != null) {
			System.out.println(userName);
			System.out.println(pwd);
		}
	}

	public static void guiPane() {
		GuiClass.guiMain();

	}
}
