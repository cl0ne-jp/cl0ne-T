package guiWorks;

/*
 * What is this?
 * This is to using application in Twitter.
 * And allways needing update.
 * Becouse this application now on alpha Version.
 * If this application upddating for users, please new writeing 'WRITING DESCRIPTIONS'
 *
 * WRITING DESCRIPTIONS
 * 【Create Date】    【Cretaer Name】    【Version】     【Description】
 * 2017/12/20     Taichi Ohkawa   Ver1.0      New Create
 *
 *Copyright 2017 Taichi Ohkawa
 *
 * */
public class MainClass {

	static JobMethod jobs;
	static String users,pwd;

	public static void methods() {
		JobMethod.guiPane();
	}

	public static void main(String[] args) {
		methods();
		jobs = new JobMethod();
		System.out.println(users + pwd);
	}
}
