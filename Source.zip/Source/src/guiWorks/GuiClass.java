package guiWorks;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
public class GuiClass extends JFrame {

	/*private values*/
	private JPanel contentPane;
	private JTextField userName;
	private JPasswordField pwdField;

	/*public values*/
    public static String  user;
    public static char[]  pwd;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					GuiClass frame = new GuiClass();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */

	public GuiClass(String userNames , char[] pwdValue){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 400);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnGetresource = new JMenu("GetResource");
		menuBar.add(mnGetresource);

		JMenuItem mntmRefresh = new JMenuItem("Refresh");
		mnGetresource.add(mntmRefresh);

		JMenuItem mntmClose = new JMenuItem("Close");
		mnGetresource.add(mntmClose);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 191, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblTwiiterApp = new JLabel("Twiiter App");
		lblTwiiterApp.setForeground(new Color(255, 255, 255));
		lblTwiiterApp.setBackground(new Color(255, 255, 255));
		lblTwiiterApp.setFont(new Font("MS UI Gothic", Font.PLAIN, 33));
		lblTwiiterApp.setBounds(580, 31, 157, 40);
		contentPane.add(lblTwiiterApp);

		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(30, 144, 255));
		btnLogin.setBounds(636, 259, 79, 21);
		contentPane.add(btnLogin);


		userName = new JTextField();
		userName.setText("your name ");
		userName.setToolTipText("");
		userName.setBounds(567, 176, 186, 21);
		contentPane.add(userName);
		userName.setColumns(10);

		pwdField = new JPasswordField();
		pwdField.setToolTipText("PassWord");
		pwdField.setBounds(567, 208, 186, 19);
		contentPane.add(pwdField);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 240));
		panel.setBounds(12, 31, 394, 284);
		contentPane.add(panel);
				panel.setLayout(null);

				JLabel getContents1 = new JLabel("New label");
				getContents1.setBounds(12, 35, 347, 99);
				panel.add(getContents1);

				JLabel getContents2 = new JLabel("New label");
				getContents2.setBounds(12, 149, 347, 99);
				panel.add(getContents2);

				JButton btnGo = new JButton("Go Twitter!");
				btnGo.setForeground(new Color(30, 144, 255));
				btnGo.setBackground(new Color(255, 255, 240));
				btnGo.setBounds(141, 10, 102, 21);
				panel.add(btnGo);

				btnGo.addActionListener(new ActionListener() {
					String urlString = "https://twitter.com/";
					Desktop dsk = Desktop.getDesktop();
					public void actionPerformed(ActionEvent arg0) {
						// TODO 自動生成されたメソッド・スタブ
						try {
							URI uri = new URI(urlString) ;
							dsk.browse(uri);
						}catch(IOException | URISyntaxException io) {
							io.printStackTrace();
						}
					}
				});


		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user = userName.getText();
			    pwd   = pwdField.getPassword();
				JobMethod.getValues(user,pwd);
			}
		});

	}

	public static void guiMain() {
		GuiClass  gcc = new GuiClass(user,pwd);
		gcc.setVisible(true);

	}
}
//	public static void guiMains() {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					GuiClass frame = new GuiClass(user,pwd);
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
//}
